package co.median.android;

public class JsResultBridge {
    public static String jsResult = "";
}
